/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen2;

import examen2.HashTable.Trophy;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author ferna
 */
public class PSNUsers {
    HashTable users;
    RandomAccessFile RAF;
    RandomAccessFile psn;
    long size=0;
  public PSNUsers(){
        
       try{
           RAF= new RandomAccessFile("users.psn","rw");
           psn=new RandomAccessFile("psn","rw");
           reloadHashTable();
       }catch(IOException e){
           e.printStackTrace();
       }
    }
    
    private void reloadHashTable(){
        size=0;
        
        try{
            users= new HashTable();
            RAF.seek(0);
            
            while(RAF.getFilePointer()<RAF.length()){
                String username=RAF.readUTF();
                int points= RAF.readInt();
                int trophies= RAF.readInt();
                boolean active=RAF.readBoolean();
                
                if(active){
                   users.add(username, size);
                size++;
                }
                
            }
            
            }catch(IOException e){
            e.printStackTrace();
        }
            }
        
    
    
    public boolean addUser(String username){
        //Agrega un nuevo registro al ARCHIVO y al HASHTABLE
        /*
        Formato:
        String username (validar que sea unico)
        int trophyPoints; (Comienza en 0)
        int trophies; (Comienza en 0)
        boolean active=true;
        */
        if(users.search(username)!=-1){
            return false;
        }
        
        //if(verifyUser(username));
        try{
            
            RAF.seek(RAF.length());
            RAF.writeUTF(username);
            RAF.writeInt(0);
            RAF.writeInt(0);
            RAF.writeBoolean(true);
            users.add(username, size);
            size++;
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
        
        
    }
    public void deactivateUser(String username){
        /*
        Cambiar boolean en archivo a false;
        Borrar en hashTable;
        
        */
       if(users.search(username)!=-1){
           try{
               RAF.seek(0);
               while(RAF.getFilePointer()<RAF.length()){
                   String user= RAF.readUTF();
                   RAF.skipBytes(8);
                   long pos=RAF.getFilePointer();
                   boolean active=RAF.readBoolean();
                   if(user.equals(username)){
                       RAF.seek(pos);
                       RAF.writeBoolean(false);
                       RAF.close();
                    
                }
                   
               }
               users.remove(username);
           }catch(IOException e){
               
           }
       }
       else JOptionPane.showInternalMessageDialog(null, "No se encontro el user");
       
    }
    public void addTrophieTo(String username,String trophyGame,String trophyName,Trophy type){
        /*
        Buscar user;
        Si se encuentra adicionar trophy;
        Trophies se guardan en raf llamado psn;
        
        FORMATO:
        Código del User que se ganó el trofeo.
        String – tipo del trofeo.
        Nombre del juego al que pertenece trofeo.
        Nombre del trofeo.
        Fecha cuando se lo gano
        */
        if(users.search(username)!=-1){
            try{
                psn.seek(psn.length());
                psn.writeUTF(username);
                psn.writeUTF(type.name());
                psn.writeUTF(trophyGame);
                psn.writeUTF(trophyName);
                Date date= new Date();
                psn.writeUTF(date.toString());
            }catch(IOException e){
                e.printStackTrace();
            }
        }
        
    }
    public String playerInfo(String username){
        /*
        Imprime toda la info del user;
        user
        puntos
        trofeos
        active
        Imprime sus trophies con el formato:
        FECHA – TIPO - JUEGO – DESCRIPCIÓN;
        */
        if(users.search(username)!=-1){
            long posUser=users.search(username);
            Entry tmp=users.inicio;
            while(tmp!=null){
                if(posUser==tmp.pos){
                    String info="Username: "+username+" "+getInfoinRAF(username);
                    return info;
                    
                }
            }
        }
        return "";
        
    }
    public String getInfoinRAF(String username){
        String info="";
        try{RAF.seek(0);
        psn.seek(0);
        while(RAF.getFilePointer()<RAF.length()){
            String user=RAF.readUTF();
            int points=RAF.readInt();
            int trophies=RAF.readInt();
            boolean active=RAF.readBoolean();
            if(user.equals(username)){
            info+="Puntos: "+points+" Trofeos: "+trophies+" Estado: "+active;
            RAF.close();
            }
        }
        while(psn.getFilePointer()<psn.length()){
        String user=psn.readUTF();
        String type=psn.readUTF();
        String gameName=psn.readUTF();
        String trophyName=psn.readUTF();
        String fecha=psn.readUTF();
        if(user.equals(username)){
        info+="\nTROFEOS:\n"+"Fecha: "+fecha+" Tipo: "+type+" Juego: "+gameName+" Descripcion: "+trophyName;
        psn.close();
        }
        }
        
        }catch(IOException e){
                e.printStackTrace();
            }
        
    return info;}
    public String show(){
        Entry tmp=users.inicio;
        String users="";
        if(this.users.inicio==null){
            return "";
        }
        while(tmp!=null){
            users+=tmp.username+"\n";
        }
        return users;
    }
}
    

